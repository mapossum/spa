print(4+6)
print(10/3)
print(20/6)
