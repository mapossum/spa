import arcpy
#inputs to Model
#Census Data
#cData = r"C:\temp\spaLab\Lab7_Data.gdb\BlockGroups_HS"
cData = arcpy.GetParameterAsText(0)
#List of Fields
#fieldList = ['POP2010','AGE_UNDER5','MALES']
fieldList = arcpy.GetParameterAsText(1).split(";")
#UserPoly
#uPoly = r"C:\temp\spaLab\Lab7_Data.gdb\userPoly"
uPoly = arcpy.GetParameterAsText(2)
#Buffer Distance
#bufDist = '1000'
bufDist = arcpy.GetParameterAsText(3)

#Output Location
#sArea = r"C:\temp\spaLab\Lab7_Data.gdb\sumArea"
sArea = arcpy.GetParameterAsText(4)

arcpy.AddMessage("Inputs: {0}  {1}   {2}".format(cData, fieldList, bufDist))

bufOutput = "in_memory/bufOut"
intOutput = "in_memory/intOut"

#Do Buffer
arcpy.Buffer_analysis(uPoly, bufOutput, bufDist)

#Do Interset
arcpy.Intersect_analysis([cData, bufOutput], intOutput)

listofSummaryFields = []
#Loop through each field
    #Add a new field to hold new values
    #caculate new value as (NewArea / OldArea) * Field Value
    #Build field list for dissolve
for field in fieldList:
    newField = field + "_ADJ"
    arcpy.AddField_management(intOutput, newField, "DOUBLE")
    fcalc = "(!shape.area! / !OArea!) * !{0}!".format(field)
    arcpy.CalculateField_management(intOutput, newField, fcalc,"PYTHON")
    listofSummaryFields.append([newField, "SUM"])
    print listofSummaryFields

#Dissolve
arcpy.Dissolve_management(intOutput, sArea, "", listofSummaryFields)




